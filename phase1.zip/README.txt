PHPExel and PHPExel.php are the library that allows to create and read xlsx files via PHP.
country list for uploads.xlsx - is a file with countries list =)
exel.php - script that writes the country list as options in select field of the form.
index.php - file with send form. Allows to add a new lead.